package com.pixelcore.app

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private val background = Color.rgb(12, 12, 16)
    private val panel = Color.rgb(28, 28, 36)
    private val white = Color.WHITE
    private val muted = Color.LTGRAY

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 40, 28, 40)
            setBackgroundColor(background)
        }

        val title = TextView(this).apply {
            text = "PIXELCORE"
            textSize = 30f
            setTextColor(white)
            gravity = Gravity.CENTER
        }

        val subtitle = TextView(this).apply {
            text = "ANIME GAME COMPANION"
            textSize = 12f
            setTextColor(muted)
            gravity = Gravity.CENTER
        }

        val addGame = Button(this).apply {
            text = "＋  ADD GAME"
            setOnClickListener { showGamePicker() }
        }

        val info = TextView(this).apply {
            text = "Pilih game secara manual untuk membuka game dari aplikasi ini."
            textSize = 13f
            setTextColor(muted)
            gravity = Gravity.CENTER
            setPadding(8, 28, 8, 8)
        }

        root.addView(title)
        root.addView(subtitle)
        root.addView(addGame)
        root.addView(info)
        setContentView(root)
    }

    private fun showGamePicker() {
        val intent = packageManager.getLaunchIntentForPackage("com.dts.freefireth")
        if (intent != null) {
            startActivity(intent)
        } else {
            android.widget.Toast.makeText(
                this,
                "Free Fire Official belum terdeteksi. Pastikan sudah terpasang.",
                android.widget.Toast.LENGTH_LONG
            ).show()
        }
    }
}
